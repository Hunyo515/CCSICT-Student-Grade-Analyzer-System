# Restart only this project's loopback server after changing local configuration.
$ErrorActionPreference = 'Stop'
$appRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$appPython = Join-Path $appRoot 'venv\Scripts\python.exe'
$listeners = @(Get-NetTCPConnection -LocalPort 5000 -State Listen -ErrorAction SilentlyContinue)
foreach ($listener in $listeners) {
    $serverProcess = Get-CimInstance Win32_Process -Filter "ProcessId = $($listener.OwningProcess)"
    $launcherProcess = Get-CimInstance Win32_Process -Filter "ProcessId = $($serverProcess.ParentProcessId)"
    if ($listener.LocalAddress -ne '127.0.0.1' -or $serverProcess.CommandLine -notmatch 'run\.py' -or $launcherProcess.ExecutablePath -ne $appPython) {
        throw 'Port 5000 belongs to an unexpected process. Nothing was stopped.'
    }
    Stop-Process -Id $serverProcess.ProcessId
}
$logs = Join-Path $appRoot 'audit\rebuild'
New-Item -ItemType Directory -Path $logs -Force | Out-Null
Start-Process -FilePath $appPython -ArgumentList 'run.py' -WorkingDirectory $appRoot -WindowStyle Hidden -RedirectStandardOutput (Join-Path $logs 'server.stdout.log') -RedirectStandardError (Join-Path $logs 'server.stderr.log') | Out-Null
Write-Output 'Local app started at http://127.0.0.1:5000/. Check audit/rebuild/server.stderr.log if it does not respond.'
