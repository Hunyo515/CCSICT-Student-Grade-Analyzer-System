"""Route old bookmarks through the new workspace; guard legacy write paths."""
from flask import request,session,redirect,url_for,abort


def install_workspace_routes(app):
    @app.before_request
    def workspace_routes():
        if not session.get('user_id'):return
        endpoint=request.endpoint or ''
        if request.method=='GET':
            if endpoint=='admin.dashboard':return redirect(url_for('workspace.overview'))
            if endpoint=='admin.analytics':return redirect(url_for('workspace.reports'))
            if endpoint in ('faculty.dashboard','faculty.top_performers'):
                return redirect(url_for('workspace.classes'))
            if endpoint=='faculty.grade_export' and request.args.get('assignment_id',type=int):
                return redirect(url_for('workspace.template',aid=request.args.get('assignment_id',type=int)))
            if endpoint in ('faculty.grade_entry','faculty.grade_weighting','faculty.section_detail','faculty.grade_registry','faculty.analytics'):
                aid=request.args.get('assignment_id',type=int)
                if aid:
                    tab={'faculty.grade_weighting':'setup','faculty.section_detail':'details','faculty.analytics':'analytics'}.get(endpoint,'gradebook')
                    return redirect(url_for('workspace.classroom',aid=aid,tab=tab))
                return redirect(url_for('workspace.classes'))
            if endpoint in ('student.dashboard','student.grades','student.analytics','student.my_rank'):
                return redirect(url_for('workspace.subjects',**({'view':'history'} if endpoint=='student.grades' else {})))
        if request.method=='POST' and endpoint=='student.join_course':
            return redirect(url_for('workspace.join'),code=307)
        if request.method=='POST' and endpoint.startswith('faculty.'):
            abort(409,description='This form belongs to the previous gradebook. Open My Classes and use the current workspace.')
        if request.method=='POST' and endpoint=='admin.assign_student_to_section':
            from .db import query_one
            aid=request.form.get('assignment_id',type=int)
            row=query_one('SELECT status FROM teacher_subjects WHERE assignment_id=:id FOR UPDATE WAIT 5',{'id':aid})
            if row and row['status'] in ('SUBMITTED','PUBLISHED'):abort(409,description='Submitted or published rosters are locked.')
