"""Program names, legacy aliases, and the retained original curriculum source."""
import json
from pathlib import Path

DATA_DIR = Path(__file__).resolve().parent / 'data' / 'curricula'
PROGRAM_NAMES = {
    'BSCS': 'Computer Science',
    'BSIT': 'Information Technology',
    'BSIS': 'Information Systems',
    'BSDSA': 'Data Science and Analytics',
    'BLIS': 'Library and Information Science',
}

PROGRAM_ALIASES = {
    'BSCS': ('BSCS','BS Computer Science','Bachelor of Science in Computer Science'),
    'BSIT': ('BSIT','BS Information Technology','Bachelor of Science in Information Technology'),
    'BSIS': ('BSIS','BS Information Systems','Bachelor of Science in Information Systems'),
    'BSDSA': ('BSDSA','BS Data Science','BS Data Science and Analytics','Bachelor of Science in Data Science and Analytics'),
    'BLIS': ('BLIS','Bachelor of Library and Information Science','BS Library and Information Science'),
}


def canonical_program(value):
    value=' '.join((value or '').split()).casefold()
    return next((code for code,aliases in PROGRAM_ALIASES.items()
                 if value in {alias.casefold() for alias in aliases}), None)


def cohort_matches(student, assignment, section):
    """A cohort is a program + year + section, never just a section name."""
    return (canonical_program(student.get('program')) == assignment.get('program')
            and assignment.get('program') in PROGRAM_NAMES
            and student.get('year_level') == assignment.get('year_level')
            and (student.get('section') or '').strip().casefold() == (section or '').strip().casefold())


def source_curriculum(program):
    if program != 'BSDSA':
        return None
    return json.loads((DATA_DIR / 'bsdsa-2023-2024.json').read_text(encoding='utf-8'))
