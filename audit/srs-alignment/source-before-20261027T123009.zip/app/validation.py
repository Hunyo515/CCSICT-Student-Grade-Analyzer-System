"""Server-side validation for all submitted fields; no dependence on browser checks."""
import math
import re
from flask import abort, request

PASSWORD_MIN_LENGTH = 8
PASSWORD_HELP = f'Use at least {PASSWORD_MIN_LENGTH} characters (maximum 72 UTF-8 bytes). Avoid common passwords.'


def password_error(value):
    if (len(value) < PASSWORD_MIN_LENGTH or len(value.encode('utf-8')) > 72
        or value.casefold() in {'password','password123','password1','12345678','123456789','qwerty123','letmein123','admin123'}):
        return PASSWORD_HELP
    return None


LIMITS = dict(username=50, first_name=74, last_name=75, full_name=150, email=150,
              subject_code=20, subject_name=150, faculty_code=20, id_number=20,
              section=20, program=100, contact_number=30, component_name=50,
              category_name=50, q=150, code=10, school_year=20, link=255,
              prerequisite_text=500, exception_reason=180, source_section=20, reason=500)
CHOICES = {
    'year_level': ('1st Year', '2nd Year', '3rd Year', '4th Year'),
    'sex': ('MALE', 'FEMALE'), 'enrollment_type': ('REGULAR', 'IRREGULAR'),
    'semester': ('1st Semester', '2nd Semester', 'Summer'),
    'semester_offered': ('1st Semester', '2nd Semester', 'Summer'),
    'redirect_to': ('grade_entry', 'grade_weighting'), 'shared': ('on',),
    'mode': ('bulk', 'individual', 'remove'), 'archived': ('0','1'), 'bracket_units': ('on',),
}
REQUIRED = {
    'auth.login': 'username password',
    'auth.forgot_password': 'username',
    'auth.register': 'first_name last_name id_number year_level section program email password confirm_password',
    'admin.add_subject': 'program subject_code subject_name units year_level semester_offered',
    'admin.edit_subject': 'program subject_code subject_name units year_level semester_offered',
    'admin.add_curriculum_subject': 'program subject_code subject_name units year_level semester_offered',
    'admin.edit_curriculum_subject': 'program subject_code subject_name units year_level semester_offered',
    'admin.add_teacher': 'full_name email faculty_code password',
    'admin.edit_teacher': 'full_name email status',
    'admin.add_student': 'first_name last_name email id_number program year_level section password',
    'admin.edit_student': 'full_name email program year_level section status',
    'admin.assign_subject': 'teacher_id subject_id section',
    'admin.assign_student_to_section': 'assignment_id mode',
    'admin.add_term': 'school_year semester', 'admin.update_profile': 'full_name email',
    'faculty.add_component': 'assignment_id component_name weight_percent',
    'faculty.add_category': 'assignment_id category_name weight_percent',
    'faculty.edit_category': 'assignment_id category_name weight_percent',
    'faculty.delete_component': 'assignment_id', 'faculty.delete_category': 'assignment_id',
    'faculty.save_scores': 'assignment_id revision', 'faculty.update_status': 'assignment_id status',
    'faculty.csv_upload': 'assignment_id', 'faculty.section_detail_toggle': 'assignment_id',
    'faculty.section_detail_regenerate': 'assignment_id', 'student.join_course': 'code',
}


def number(value, low, high, integer=False):
    try:
        n = float(value)
        return math.isfinite(n) and low <= n <= high and (not integer or n.is_integer())
    except (ValueError, TypeError):
        return False


def field_error(key, value, endpoint='', post=True):
    label = key.replace('_', ' ').capitalize()
    if key in LIMITS and len(value.encode('utf-8')) > LIMITS[key]:
        return f'{label} must be at most {LIMITS[key]} bytes.'
    if any(ord(c) < 32 for c in value):
        return f'{label} contains invalid control characters.'
    if not value.strip():
        if key.startswith("score__") and not re.fullmatch(r"score__[1-9][0-9]*__[1-9][0-9]*", key):
            return "Invalid score field."
        return None
    if key in CHOICES and value not in CHOICES[key]:
        return f'Select a valid {label.lower()}.'
    if key == 'status' and value not in (('DRAFT', 'IN_PROGRESS', 'PUBLISHED') if endpoint == 'faculty.update_status' else ('ACTIVE', 'INACTIVE')):
        return 'Select a valid status.'
    if key == 'email' and not re.fullmatch(r'[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+', value):
        return 'Enter a valid email address.'
    if key == 'subject_code' and not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9 ./_\-]*', value):
        return 'Course code contains invalid characters.'
    if key in ('username', 'faculty_code', 'id_number', 'code') and not re.fullmatch(r'[A-Za-z0-9_.@+\-]+', value):
        return f'{label} contains invalid characters.'
    if key == 'contact_number' and not re.fullmatch(r'\+?[0-9 ()-]{7,30}', value):
        return 'Enter a valid contact number.'
    if key == 'school_year' and (not re.fullmatch(r'\d{4}-\d{4}', value) or int(value[5:]) != int(value[:4]) + 1):
        return 'School year must use consecutive years, such as 2026-2027.'
    if key in ('password', 'new_password') and endpoint != 'auth.login':
        return password_error(value)
    if key in ('password', 'confirm_password') and len(value.encode('utf-8')) > 72:
        return 'Password is too long (maximum 72 UTF-8 bytes).'
    if key.endswith('_id') or key == 'page':
        if not re.fullmatch(r'[0-9]+', value) or not number(value, 1, 2147483647, True):
            return f'{label} must be a positive integer.'
    if key == 'revision' and (not re.fullmatch(r'[0-9]+', value) or not number(value, 0, 2147483647, True)):
        return 'Invalid form revision.'
    if key == 'units' and not number(value, 1, 6, True):
        return 'Units must be a whole number from 1 to 6.'
    if key in ('lecture_units','lab_units') and not number(value,0,6,True):
        return 'Lecture and laboratory units must be whole numbers from 0 to 6.'
    if key == 'weight_percent' and not number(value, 0, 100):
        return 'Weight must be between 0 and 100.'
    if key.startswith('score__'):
        if not re.fullmatch(r'score__[1-9][0-9]*__[1-9][0-9]*', key) or not number(value, 0, 100):
            return 'Scores must be finite numbers from 0 to 100.'
    return None


def validate_request():
    data = request.form if request.method == 'POST' else request.args
    errors = []
    if request.method == 'POST':
        for key in REQUIRED.get(request.endpoint, '').split():
            if not data.get(key, '').strip():
                errors.append(f'{key.replace("_", " ").capitalize()} is required.')
    for key in data:
        if len(data.getlist(key)) != 1:
            errors.append(f'Duplicate field: {key}.')
        if len(data[key]) > 4096:
            errors.append('Input is too long.')
        else:
            error = field_error(key, data[key], request.endpoint, request.method == 'POST')
            if error:
                errors.append(error)
    if request.endpoint in ("admin.add_subject", "admin.edit_subject", "admin.add_curriculum_subject", "admin.edit_curriculum_subject") and data.get("program") not in ("BSCS", "BSIT", "BSIS", "BSDSA", "BLIS"):
        errors.append("Select a valid curriculum program.")
    if request.method=='POST' and request.endpoint in ('auth.register','admin.add_student','admin.edit_student'):
        from .curriculum import canonical_program
        if not canonical_program(data.get('program')):
            errors.append('Choose a supported program.')
    if errors:
        abort(400, description=' '.join(errors[:8]))
