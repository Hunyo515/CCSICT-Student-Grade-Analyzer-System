document.addEventListener('submit', function (event) {
  const form = event.target;
  if (event.defaultPrevented || form.method.toLowerCase() !== 'post') return;
  if (form.dataset.confirm && !window.confirm(form.dataset.confirm)) { event.preventDefault(); return; }
  if (form.dataset.submitting === 'true') { event.preventDefault(); return; }
  form.dataset.submitting = 'true';
  form.setAttribute('aria-busy', 'true');
  const note = document.createElement('p');
  note.setAttribute('role', 'status');
  note.textContent = 'Submitting. Please wait for confirmation before trying again.';
  form.appendChild(note);
  // Preserve submitter names/values until the browser has serialized the form.
  setTimeout(function () {
    form.querySelectorAll('button[type="submit"]').forEach(function (button) { button.disabled = true; });
  }, 0);
});
window.addEventListener('pageshow', function () {
  document.querySelectorAll('form').forEach(function(form) {
    delete form.dataset.submitting;
    form.removeAttribute('aria-busy');
    form.querySelectorAll('button[type="submit"]').forEach(function(button) { button.disabled = false; });
  });
});
