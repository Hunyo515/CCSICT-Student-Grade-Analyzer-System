from flask import Blueprint, flash, redirect, render_template, request, session, url_for

from ..curriculum import canonical_program
from ..auth import hash_password, verify_password
from ..db import execute, execute_returning_id, query_all, query_one
from ..notifications import notify_many
from ..validation import PASSWORD_MIN_LENGTH

auth_bp = Blueprint("auth", __name__)

ROLE_DASHBOARD = {
    "admin": "admin.dashboard",
    "faculty": "faculty.dashboard",
    "student": "student.dashboard",
}

ROLE_LABELS = {
    "admin": "Admin",
    "faculty": "Faculty",
    "student": "Student",
}


@auth_bp.route("/")
def select_role():
    if session.get("user_id") and session.get("role") in ROLE_DASHBOARD:
        return redirect(url_for(ROLE_DASHBOARD[session['role']]))
    return render_template("auth/select_role.html")


@auth_bp.route("/login/<role>", methods=["GET", "POST"])
def login(role):
    if role not in ROLE_DASHBOARD:
        return redirect(url_for("auth.select_role"))

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")

        user = query_one(
            """
            SELECT user_id, username, password_hash, role, full_name, status, email
            FROM users
            WHERE username = :username AND role = :role
            """,
            {"username": username, "role": role},
        )

        if not user or user["status"] != "ACTIVE" or not verify_password(password, user["password_hash"]):
            flash("Invalid username or password.", "error")
            return render_template("auth/login.html", role=role, role_label=ROLE_LABELS[role])

        from ..email_otp import begin
        import smtplib
        try:
            begin(user)
        except (RuntimeError, OSError, smtplib.SMTPException) as error:
            from flask import current_app
            current_app.logger.warning('Email sign-in delivery failed: %s',type(error).__name__)
            flash(str(error) if isinstance(error,RuntimeError) else 'Email delivery failed. Please try again or contact your administrator.', 'error')
            return render_template('auth/login.html',role=role,role_label=ROLE_LABELS[role]),503
        return redirect(url_for('auth.otp'))

    return render_template("auth/login.html", role=role, role_label=ROLE_LABELS[role])


@auth_bp.route('/verify-email',methods=['GET','POST'])
def otp():
    from ..email_otp import pending,consume,begin
    challenge=pending()
    if not challenge:
        flash('Sign in to request a new code.','error')
        return redirect(url_for('auth.select_role'))
    user=query_one('SELECT user_id,username,password_hash,role,full_name,status,email FROM users WHERE user_id=:id',{'id':challenge['user_id']})
    if not user or user['status']!='ACTIVE' or user['role']!=session.get('otp_role'):
        session.clear();return redirect(url_for('auth.select_role'))
    from ..security import credential_fingerprint
    import hmac
    if not hmac.compare_digest(challenge['credential'],credential_fingerprint(user['password_hash']+'|'+(user.get('email') or ''))):
        session.clear();return redirect(url_for('auth.select_role'))
    if request.method=='POST':
        if request.form.get('action')=='resend':
            import smtplib
            try:begin(user);flash('A new code was sent. Previous codes no longer work.','success')
            except (RuntimeError,OSError,smtplib.SMTPException) as error:
                flash(str(error) if isinstance(error,RuntimeError) else 'Email delivery failed. Please retry.','error')
        elif consume(request.form.get('otp','').strip(),user):
            profile=None
            if user['role'] in ('faculty','student'):
                table,key=('teachers','teacher_id') if user['role']=='faculty' else ('students','student_id')
                profile=query_one(f'SELECT {key},status FROM {table} WHERE user_id=:id',{'id':user['user_id']})
                if not profile or profile['status']!='ACTIVE':session.clear();return redirect(url_for('auth.select_role'))
            session.clear();session.permanent=True
            from ..security import create_session
            create_session(user)
            session.update({k:user[k] for k in ('user_id','username','full_name','role')})
            if profile:session[key]=profile[key]
            return redirect(url_for(ROLE_DASHBOARD[user['role']]))
        else:flash('Invalid or expired code. Request a new code if needed.','error')
    return render_template('auth/otp.html')


@auth_bp.route("/logout", methods=["POST"])
def logout():
    from ..security import revoke_session
    revoke_session()
    session.clear()
    flash("You have been logged out.", "success")
    return redirect(url_for("auth.select_role"))


@auth_bp.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        first_name = request.form.get("first_name", "").strip()
        last_name = request.form.get("last_name", "").strip()
        id_number = request.form.get("id_number", "").strip().upper()
        year_level = request.form.get("year_level", "").strip()
        section = request.form.get("section", "").strip()
        program = canonical_program(request.form.get("program", ""))
        email = request.form.get("email", "").strip()
        sex = request.form.get("sex", "").strip() or None
        password = request.form.get("password", "")
        confirm_password = request.form.get("confirm_password", "")

        form_data = {k:v for k,v in request.form.items() if "password" not in k and k != "csrf_token"}

        if not all([first_name, last_name, id_number, year_level, section, program, email, password]):
            flash("Please fill in all required fields.", "error")
            return render_template("auth/registration.html", form=form_data)

        if password != confirm_password:
            flash("Passwords do not match.", "error")
            return render_template("auth/registration.html", form=form_data)

        if len(password) < PASSWORD_MIN_LENGTH:
            flash(f"Password must be at least {PASSWORD_MIN_LENGTH} characters.", "error")
            return render_template("auth/registration.html", form=form_data)

        if query_one("SELECT student_id FROM students WHERE id_number = :i", {"i": id_number}):
            flash(f"ID number {id_number} is already registered.", "error")
            return render_template("auth/registration.html", form=form_data)

        username = id_number.lower()
        if query_one("SELECT user_id FROM users WHERE username = :u", {"u": username}):
            flash("An account with this ID already exists.", "error")
            return render_template("auth/registration.html", form=form_data)

        full_name = f"{first_name} {last_name}"
        user_id = execute_returning_id(
            """
            INSERT INTO users (username, password_hash, role, full_name, email, status)
            VALUES (:username, :pw, 'student', :full_name, :email, 'INACTIVE')
            RETURNING user_id INTO :out_id
            """,
            {"username": username, "pw": hash_password(password), "full_name": full_name, "email": email},
        )
        execute(
            """
            INSERT INTO students (user_id, id_number, program, year_level, section, sex, enrollment_type, status)
            VALUES (:user_id, :id_number, :program, :year_level, :section, :sex, 'REGULAR', 'INACTIVE')
            """,
            {"user_id": user_id, "id_number": id_number, "program": program, "year_level": year_level, "section": section, "sex": sex},
        )

        flash("Registration submitted. An administrator must verify your student identity and activate your account before you can sign in.", "success")
        return redirect(url_for("auth.login", role="student"))

    return render_template("auth/registration.html", form={})


@auth_bp.route("/forgot-password/<role>", methods=["GET", "POST"])
def forgot_password(role):
    if role not in ROLE_DASHBOARD:
        return redirect(url_for("auth.select_role"))

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        user = query_one(
            "SELECT user_id, full_name FROM users WHERE username = :u AND role = :r",
            {"u": username, "r": role},
        )
        if user:
            admins = query_all("SELECT user_id FROM users WHERE role = 'admin' AND status = 'ACTIVE'")
            notify_many(
                [a["user_id"] for a in admins],
                f"Password reset requested by {user['full_name']} ({ROLE_LABELS[role]}, username: {username}).",
                link=url_for("admin.teachers" if role == "faculty" else "admin.students" if role == "student" else "admin.settings"),
            )
        # Always show the same message whether or not the account exists,
        # so this can't be used to check which usernames are registered.
        flash("If that account exists, your system administrator has been notified and will reach out to reset your password.", "success")
        return redirect(url_for("auth.login", role=role))

    return render_template("auth/forgot_password.html", role=role, role_label=ROLE_LABELS[role])
