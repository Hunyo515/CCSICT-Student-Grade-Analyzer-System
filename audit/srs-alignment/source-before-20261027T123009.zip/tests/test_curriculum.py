import unittest
from unittest.mock import patch
from xml.etree import ElementTree as ET
from zipfile import ZipFile
from app.curriculum import DATA_DIR, source_curriculum
from audit_fixture import AuditFixture


class CurriculumTests(unittest.TestCase):
    def test_import_matches_every_source_cell(self):
        curriculum = source_curriculum('BSDSA')
        semesters = [s for y in curriculum['years'] for s in y['semesters']]
        self.assertEqual(len(semesters), 8)
        self.assertEqual(sum(len(s['courses']) for s in semesters), 52)
        ns = {'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
        with ZipFile(DATA_DIR / 'bsdsa-2023-2024.docx') as doc:
            root = ET.fromstring(doc.read('word/document.xml'))
        tables = root.findall('.//w:body/w:tbl', ns)
        self.assertEqual(len(tables), len(semesters))
        for table, semester in zip(tables, semesters):
            rows = [['\n'.join(''.join(t.text or '' for t in p.findall('.//w:t', ns))
                               for p in cell.findall('w:p', ns))
                     for cell in row.findall('w:tc', ns)] for row in table.findall('w:tr', ns)]
            courses = [[c[k] for k in ('code','title','units','lecture','laboratory','prerequisite')]
                       for c in semester['courses']]
            self.assertEqual(courses, rows[1:-1])
            self.assertEqual([semester['totals'][k] for k in ('units','lecture','laboratory')], rows[-1][2:5])

    def test_source_ambiguities_are_preserved(self):
        curriculum = source_curriculum('BSDSA')
        courses = [c for y in curriculum['years'] for s in y['semesters'] for c in s['courses']]
        self.assertEqual(sum(c['code'] == 'DSA 315' for c in courses), 2)
        self.assertEqual(sum(c['units'] == '(3)' for c in courses), 2)
        self.assertTrue(any('DSA 412' in note and 'DSA 421' in note for note in curriculum['notes']))

    def test_folders_and_program_routes(self):
        with AuditFixture() as fixture:
            client = fixture.client('admin')
            response = client.get('/admin/subjects')
            self.assertEqual(response.status_code, 200)
            self.assertEqual(response.data.count(b'class="curriculum-folder"'), 5)
            for program in ('BSCS','BSIT','BSIS','BLIS','BSDSA'):
                response = client.get('/admin/subjects?program='+program)
                self.assertEqual(response.status_code, 200)
            self.assertIn(b'Add subject', response.data)
            self.assertEqual(client.get('/admin/subjects?program=UNKNOWN').status_code, 404)
            self.assertEqual(client.get('/admin/subjects/curriculum').status_code,302)
            download = client.get('/admin/subjects/curriculum/bsdsa/source')
            self.assertEqual(download.status_code, 200)
            self.assertTrue(download.data.startswith(b'PK'))
            download.close()

    def test_database_subjects_render_with_edit_and_class_actions(self):
        from scripts.migrate_curriculum_workflow import import_rows
        rows=[dict(subject_id=i,subject_code=r['code'],subject_name=r['name'],units=r['units'],
              year_level=r['year_level'],semester_offered=r['semester'],program='BSDSA',
              lecture_units=r['lecture'],lab_units=r['lab'],prerequisite_text=r['prerequisite'],
              units_note=r['note'],is_archived=0,prerequisite_code=None) for i,r in enumerate(import_rows(),1)]
        with AuditFixture() as fixture:
            client=fixture.client('admin')
            with patch('app.routes.admin.query_all',return_value=rows):
                response=client.get('/admin/subjects?program=BSDSA')
            self.assertEqual(response.status_code,200)
            self.assertIn(b'Fundamentals of Programming',response.data)
            self.assertIn(b'On-the-Job Training (320 hours)',response.data)
            self.assertEqual(response.data.count(b'>Create class</a>'),52)
            self.assertEqual(response.data.count(b'>Edit</a>'),52)

    def test_source_is_admin_only(self):
        with AuditFixture() as fixture:
            for role in ('faculty','student'):
                self.assertEqual(fixture.client(role).get('/admin/subjects/curriculum/bsdsa/source').status_code,302)


if __name__ == '__main__':
    unittest.main()
